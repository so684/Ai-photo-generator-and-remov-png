
function generateImage() {
    const prompt = document.getElementById('prompt').value;
    const resultDiv = document.getElementById('result');
    resultDiv.innerHTML = `<p>Generated Image for: <strong>${prompt}</strong></p><img src="https://via.placeholder.com/300?text=${encodeURIComponent(prompt)}" alt="Generated Image">`;
}
